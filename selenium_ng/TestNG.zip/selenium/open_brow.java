package selenium;

import org.openqa.selenium.firefox.FirefoxDriver;

public class open_brow {

	public static void main(String[] args) {
		FirefoxDriver driver = new FirefoxDriver();
		driver.get("https://www.google.co.in/");
		

	}

}