package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class mouse_over1 {
	WebDriver d;
	@Test
	public void get(){
		d = new FirefoxDriver();
		d.get("http://www.amazon.in/");
		Actions a = new Actions(d);
		
		d.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS); 		
		WebElement b = d.findElement(By.xpath(".//*[@id='nav-link-shopall']"));
		WebElement c = d.findElement(By.xpath(".//*[@id='nav-flyout-shopAll']/div[2]/span[4]/span[1]"));
		a.moveToElement(b).moveToElement(c).build().perform();
		WebElement h = d.findElement(By.xpath(".//*[@id='nav-flyout-shopAll']/div[3]/div[4]/div[2]/div/a[2]/span"));
		h.click();
		
		
	}
	
}
